For Linux OS: 
    python app.py

For Windows OS:
    python app.py 
    py app.py

For MAC:
    python app.py

Requirements:
    install all modules in requirements.txt
    If the active scan give any error install nmap for the os you are in.


Testing :   http://testphp.vulnweb.com/